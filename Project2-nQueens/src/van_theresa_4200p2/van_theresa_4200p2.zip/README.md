Theresa Van <br>
CS 4200-01  <br>
In van_theresa_4200p2 run the command "javac Main.java" to build, then the command "java Main" to run the program. No user input is needed.